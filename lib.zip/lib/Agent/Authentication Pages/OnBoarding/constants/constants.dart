// ignore_for_file: constant_identifier_names

class Constants{

  static String OPEN_SANS = "OpenSans";
  //static String Montserrat = "Montserrat";
  //static String MontserratLight = "Montserrat-Light";
  //static String TrenchThin = "TrenchThin";

  static String SKIP = "Skip";
  static String BACK = "Back";
  static String NEXT = "Next";
  static String DONE = "DONE";

  static String SLIDER_HEADING_1 = "Welcome to VisaBoard";
  static String SLIDER_HEADING_2 = "Easy to Use!";
  static String SLIDER_HEADING_3 = "Exclusive Products";
  static String SLIDER_DESC1 = "Welcome to VisaBoard! Introducing visa assistance service portal. Let's go digital..!!";
  static String SLIDER_DESC2 = "Select the service you want, pay online, upload required documents and your requested service will be delivered to you shortly.";
  static String SLIDER_DESC3 = "VisaFile SOP, Appeal Letter(for refused student), University SOP, Caips Note and many more.";
}
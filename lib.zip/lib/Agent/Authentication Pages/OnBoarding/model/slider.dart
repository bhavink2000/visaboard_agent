//@dart=2.9
import 'package:flutter/cupertino.dart';

import '../constants/constants.dart';

class Slider {
  final String sliderImageUrl;
  final String sliderHeading;
  final String sliderSubHeading;

  Slider({
      @required this.sliderImageUrl,
      @required this.sliderHeading,
      @required this.sliderSubHeading
  });
}

final sliderArrayList = [
    Slider(
        sliderImageUrl: 'assets/lottie/118851-lightblue-paper-airplane.json',
        sliderHeading: Constants.SLIDER_HEADING_1,
        sliderSubHeading: Constants.SLIDER_DESC1),
    Slider(
        sliderImageUrl: 'assets/lottie/6574-flymap.json',
        sliderHeading: Constants.SLIDER_HEADING_2,
        sliderSubHeading: Constants.SLIDER_DESC2),
    Slider(
        sliderImageUrl: 'assets/lottie/58918-legal-statement.json',
        sliderHeading: Constants.SLIDER_HEADING_3,
        sliderSubHeading: Constants.SLIDER_DESC3),
];

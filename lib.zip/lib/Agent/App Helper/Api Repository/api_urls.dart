// ignore_for_file: constant_identifier_names, non_constant_identifier_names
class ApiConstants {

  static String URL = "https://demo.visaboard.in/api/vb-agent/user/";

  static String Login = "https://demo.visaboard.in/api/vb-agent/login";

  static String SignUp = "https://demo.visaboard.in/api/vb-agent/signup";

  static String ForgotPassowrd = "https://demo.visaboard.in/api/vb-agent/post-forgot-password";
  static String ChangePassword = "https://demo.visaboard.in/api/vb-agent/change-password";

  static String getProfile = "https://demo.visaboard.in/api/vb-agent/edit-profile";

  static String getDashBoardCounter = "${URL}dashboard/counter";
  static String getWalletDashBoard = "${URL}sop/wallet-transaction/list";
  static String getNotification = "${URL}sop/list/unread";

  static String getTemplate = "https://demo.visaboard.in/api/vb-agent/get-templates-list";

  static String getQuickApply = "https://demo.visaboard.in/api/vb-agent/quick-apply";
  static String getClientList = "https://demo.visaboard.in/api/vb-agent/user/list/full-list";
  static String getCheckShowData = "https://demo.visaboard.in/api/vb-agent/letter-type/get";

  static String getClient = "${URL}list";
  static String getClientAdd = "${URL}add";
  static String getSopCalculation = "https://demo.visaboard.in/api/vb-agent/sop-calculation";
  static String CheckPaymentMethod = "${URL}check-available-payment-method";
  static String CheckRozarPayPayment = "${URL}sop/payment/razorpay-pay";
  static String CheckStripePayment = "${URL}sop/payment/stripe-pay";

  static String getQRCode = "${URL}download-qr-code";
  static String getQRSticker = "${URL}download-qr-code/download/sticker";
  static String getQRDownload = "${URL}download-qr-code/download";
  static String getQRApplyStandee = "${URL}download-qr-code/apply-for-standee";


  static String getWalletTransaction = "${URL}wallet/list";
  static String getWalletAdd = "${URL}wallet/add";
  static String getWalletWithdraw = "${URL}wallet/withdraw/add";

  static String getTransaction = "${URL}transaction/list";

  static String getOrderVisaFile = "${URL}sop/list";
  static String SendMessage = "https://demo.visaboard.in/api/vb-agent/send/message";
  static String getOVFEdit = "${URL}edit";
  static String getOVFUpdate = "${URL}update";
  static String getOVFChat = "${URL}sop/";

  static String getUploadDocs = "${URL}upload-document";

  static String getServiceRequestedAdd = "${URL}apply-sop";
  static String getServiceRequested = URL;

}

class ApiUrls{

  static String URL = "https://demo.visaboard.in/api/vbx/";

  static String getCountry = "${URL}get-country";
  static String getState = "${URL}get-state-by-country";
  static String getCity = "${URL}get-city-state-and-country";

  static String getServiceType = "${URL}get-service-type";
  static String getLetterType = "${URL}get-letter-type";
}

class SocialMedia{
  static String getIndeed = "https://demo.visaboard.in/assets/images/linkedin.png";
  static String getFacebook = "https://demo.visaboard.in/assets/images/facebook.png";
  static String getInstagram = "https://demo.visaboard.in/assets/images/instagram.png";
  static String getTwitter = "https://demo.visaboard.in/assets/images/twitter.png";
  static String getYoutube = "https://demo.visaboard.in/assets/images/youtube.png";
  static String getWebSite = "https://demo.visaboard.in/assets/images/website.png";
}
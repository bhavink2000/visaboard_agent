// ignore_for_file: constant_identifier_names

class DrawerMenusName{

  static const client = 'client_page';

  static const order_visa_file = 'order_visa_file';

  static const template = 'template_page';

  static const transaction = 'transaction_page';

  static const wallet_page_d = 'wallet_page';

  static const lead_management = 'lead_management_page';

  static const followup = 'followup_page';

  static const agent_qrcode = 'agent_qrcode_page';

}
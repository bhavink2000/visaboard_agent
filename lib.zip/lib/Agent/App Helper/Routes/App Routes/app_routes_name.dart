class AppRoutesName {

  static const login = 'login_screen';

  static const splashscreen = 'splash_screen';

  static const landingpage = 'landing_page';

  static const dashboard = 'dashboard_agent';

  static const profile = 'profile_page';
}
// ignore_for_file: import_of_legacy_library_into_null_safe

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:provider/provider.dart';
import '../../Api Repository/User Authentication/user_authentication.dart';
import '../../Models/App Model/login_model.dart';
import '../../Routes/App Routes/app_routes_name.dart';
import '../../Ui Helper/loading.dart';
import '../../Ui Helper/snackbar_msg_show.dart';
import 'user_data_auth_session.dart';

class AuthProvider with ChangeNotifier{

  final _myUser = UserAuthentication();

  bool _loading = false;
  bool get loading => _loading;
  setLoginLoading(bool value) {
    _loading = value;
    notifyListeners();
  }

  Future<void> loginApi(dynamic data, BuildContext context)async {
    LoadingIndicater().onLoad(true, context);
    setLoginLoading(true);
    _myUser.loginApi(data).then((value){
      setLoginLoading(false);
      final userDataSession = Provider.of<UserDataSession>(context, listen: false);
      userDataSession.saveUserData(
        UserLogin(
          accessToken: value['access_token'].toString(),
          encAgentId: value['enc_agent_id'],
          id: value['data']['id'],
          countryId: value['data']['country_id'],
        )
      );
      SnackBarMessageShow.successsMSG('Login Successfully', context);
      Navigator.pushNamed(context, AppRoutesName.dashboard);
      LoadingIndicater().onLoadExit(false, context);
      if (kDebugMode) {
        print(value);
      }
    }).onError((error, stackTrace){
      setLoginLoading(false);
      Navigator.pop(context);
      SnackBarMessageShow.errorMSG(error.toString(), context);
    });
  }
}